import { Component } from '@angular/core';

@Component({
  selector: 'app-changepassword',
  standalone: true,
  imports: [],
  templateUrl: './changepassword.component.html',
  styleUrl: './changepassword.component.css'
})
export class ChangepasswordComponent {

}
