import mongoose from "mongoose";
const database_connectivity=async ()=>{
 try{
    await mongoose.connect("mongodb://localhost:27017/batch54project");
    console.log("MongoDb connected");
 }
 catch(err){
    console.log("Mongodb not connected")
 }
}
export default database_connectivity;